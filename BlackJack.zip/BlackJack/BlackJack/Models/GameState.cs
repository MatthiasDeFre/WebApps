﻿namespace BlackJackGame.Models {
    public enum GameState {
        GameOver = 1,
        PlayerPlays = 2,
        DealerPlays = 3
    }
}
