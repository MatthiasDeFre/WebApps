﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace BlackJackGame.Models
{
    public class Deck
    {
        #region Fields

        private static Random _random;
        private IList<BlackJackCard> _cards;
        #endregion

        #region Properties

        

        #endregion

        #region Constructors

        public Deck()
        {
           _cards = new List<BlackJackCard>();
            foreach (Suit suit in Enum.GetValues(typeof(Suit)))
            {
                foreach (FaceValue face in Enum.GetValues(typeof(FaceValue)))
                {
                    _cards.Add(new BlackJackCard(face, suit));
                }
            }
            Shuffle();
        }

        #endregion

        #region Methods

        public BlackJackCard DrawCard()
        {
            if(_cards.Count == 0) 
                throw new InvalidOperationException("Test");
            BlackJackCard card = _cards[0];
            _cards.Remove(card);
            return card;
        }

        private void Shuffle()
        {
            _random = new Random();
            int n = _cards.Count;
            while (n > 1)
            {
                n--;
                int k = _random.Next(n + 1);
                BlackJackCard value = _cards[k];
                _cards[k] = _cards[n];
                _cards[n] = value;
            }
            
        }


        #endregion

    }
}
