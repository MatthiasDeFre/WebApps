﻿using System;
using System.Collections.Generic;
using System.Reflection.PortableExecutable;
using System.Text;

namespace BlackJackGame.Models
{
    public class BlackJack
    {
        #region Fields

        private Deck _deck;
        #endregion

        #region Properties

        public Hand DealerHand{ get; private set; }
        public Hand PlayerHand { get; private set; }
        public GameState GameState { get; private set; }
        #endregion

        #region Constructors

        public BlackJack()
        {
            
        }

        public BlackJack(Deck deck)
        {
            _deck = deck;
        }


        #endregion

        #region Methods

        private void Deal()
        {

        }

        public String GameSummary()
        {
            return "";
        }

        public void GivePlayerAnotherCard()
        {
            
        }

        private void LetDealerFinalize()
        {
            
        }

        public void PassToDealer()
        {
            
        }
        #endregion
    }
}
