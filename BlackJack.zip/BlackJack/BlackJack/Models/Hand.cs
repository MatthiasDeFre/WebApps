﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BlackJackGame.Models
{
    public class Hand
    {
        #region Fields



        #endregion

        #region Properties

        public int NrOfCards { get; private set; }

        public int Value
        {
            get { return CalculateValue(); }
           
        }

        private IList<BlackJackCard> _cards;

        public IEnumerable<BlackJackCard> Cards
        {
            get { return _cards; }
        }

        #endregion

        #region Constructors

        public Hand()
        {
            _cards = new List<BlackJackCard>();
            NrOfCards = 0;
        }

        #endregion

        #region Methods

        public void AddCard(BlackJackCard blackJackCard)
        {
            _cards.Add(blackJackCard);
            NrOfCards++;
        }

        private int CalculateValue()
        {
            int score = 0;
            foreach (BlackJackCard blackJackCard in _cards)
            {
                if (blackJackCard.FaceUp)
                {
                    if (blackJackCard.FaceValue == FaceValue.Ace && score + 11 <= 21)
                    {
                        score += 11;
                    }
                    else
                    {
                        score += Math.Min(10, (int)blackJackCard.FaceValue);
                    }
                }
                
            }
            return score;
        }

        public void TurnAllCardsFaceUp()
        {
            foreach (BlackJackCard blackJackCard in _cards)
            {
                if (!blackJackCard.FaceUp)
                {
                    blackJackCard.TurnCard();
                }
            }
        }
        #endregion
    }
}
