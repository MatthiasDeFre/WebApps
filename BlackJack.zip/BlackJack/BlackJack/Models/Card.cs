﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BlackJackGame.Models
{
    public class Card
    {
        #region Properties
        public FaceValue FaceValue { get; private set; }
        public Suit Suit { get; private set; }
        #endregion

        #region Constructors

        public Card(FaceValue face, Suit suit)
        {
            FaceValue = face;
            Suit = suit;
        }


        #endregion

        #region Methods

        

        #endregion


    }
}
