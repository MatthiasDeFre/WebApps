﻿using System;
using BlackJackGame.Models;
using Xunit;


namespace BlackJackGame.Tests.Models
{
    public class DeckTest
    {
        private Deck deck;
        public DeckTest()
        {
            deck = new Deck();
        }
        [Fact]
        public void Draw_GivesInstanceBlackJackCard()
        {
           
            Assert.IsType<BlackJackCard>(deck.DrawCard());
        }
        
        [Fact]
        public void DrawEmptyDeck_GivesInvalidOperationException()
        {
          
            for (int i = 0; i < 52; i++)
            {
                deck.DrawCard();
            }
            Assert.Throws<InvalidOperationException>(() => deck.DrawCard());
        }

        [Fact]
        public void newDeck_52CardsFaceDown()
        {
          
            bool faceDown = true;
            for (int i = 0; i < 52; i++)
            {
                BlackJackCard card = deck.DrawCard();
                if (card.FaceUp)
                {
                    faceDown = false;
                }
            }
            Assert.True(faceDown);
        }
        [Fact (Skip="Not yet implemented and bad test")]
        public void Shuffle_ChangesOrder()
        {         
            BlackJackCard card = deck.DrawCard();
            Boolean randomCard = true;
            if (card.Suit != Suit.Hearts && card.Value != Math.Min(10, (int) FaceValue.Ace))
            {

            }
        }
    }
}
